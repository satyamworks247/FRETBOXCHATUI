export const Baseurl = "https://fretboxbackend.brandbell.in";
// export const Baseurl = "https://chatbox.binarydots.com";
