import { useEffect, useState } from "react";
import { Plus, X, Check, Users, Search, Image, Crown, Shield, UserPlus, MessageCircle } from "lucide-react";
import { useChatStore } from "../store/useChatStore";
import toast from "react-hot-toast";

// Updated mock data with requested names
const mockUsers = [
  {
    _id: "user1",
    fullName: "Thapar Admin",
    profilePic: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face&auto=format",
    role: "admin",
    isOnline: true,
    email: "admin@thapar.edu"
  },
  {
    _id: "user2",
    fullName: "VIT Registrar",
    profilePic: "https://images.unsplash.com/photo-1494790108755-2616b612b0aa?w=150&h=150&fit=crop&crop=face&auto=format",
    role: "admin",
    isOnline: true,
    email: "registrar@vit.ac.in"
  },
  {
    _id: "user3",
    fullName: "Narendra Modi",
    profilePic: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face&auto=format",
    role: "admin",
    isOnline: false,
    email: "pm@india.gov.in"
  },
  {
    _id: "user4",
    fullName: "Rufina Siddiqui KIIT",
    profilePic: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150&h=150&fit=crop&crop=face&auto=format",
    role: "moderator",
    isOnline: true,
    email: "rufina@kiit.ac.in"
  },
  {
    _id: "user5",
    fullName: "BITS Pilani Admin",
    profilePic: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&h=150&fit=crop&crop=face&auto=format",
    role: "admin",
    isOnline: false,
    email: "admin@bits-pilani.ac.in"
  },
  {
    _id: "user6",
    fullName: "IIT Delhi Professor",
    profilePic: "https://images.unsplash.com/photo-1519244703995-f4e0f30006d5?w=150&h=150&fit=crop&crop=face&auto=format",
    role: "moderator",
    isOnline: true,
    email: "prof@iitd.ac.in"
  },
  {
    _id: "user7",
    fullName: "NIT Warangal Dean",
    profilePic: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=150&h=150&fit=crop&crop=face&auto=format",
    role: "admin",
    isOnline: true,
    email: "dean@nitw.ac.in"
  },
  {
    _id: "user8",
    fullName: "AIIMS Director",
    profilePic: "https://images.unsplash.com/photo-1582750433449-648ed127bb54?w=150&h=150&fit=crop&crop=face&auto=format",
    role: "admin",
    isOnline: false,
    email: "director@aiims.edu"
  },
  {
    _id: "user9",
    fullName: "JNU Student Council",
    profilePic: "https://images.unsplash.com/photo-1544725176-7c40e5a71c5e?w=150&h=150&fit=crop&crop=face&auto=format",
    role: "member",
    isOnline: true,
    email: "council@jnu.ac.in"
  },
  {
    _id: "user10",
    fullName: "DU Vice Chancellor",
    profilePic: "https://images.unsplash.com/photo-1567515004624-219c11d31f2e?w=150&h=150&fit=crop&crop=face&auto=format",
    role: "admin",
    isOnline: true,
    email: "vc@du.ac.in"
  }
];

const mockGroups = [
  {
    _id: "group1",
    groupName: "University Administrators",
    groupImage: "https://images.unsplash.com/photo-1522071820081-009f0129c71c?w=150&h=150&fit=crop&auto=format",
    memberCount: 12,
    isGroup: true,
    latestMessage: {
      content: "Annual meeting scheduled for next week",
      timestamp: "2 hours ago",
      sender: "Thapar Admin"
    },
    isActive: true
  },
  {
    _id: "group2",
    groupName: "Education Ministry",
    groupImage: "https://images.unsplash.com/photo-1559136555-9303baea8ebd?w=150&h=150&fit=crop&auto=format",
    memberCount: 8,
    isGroup: true,
    latestMessage: {
      content: "New education policy implementation updates",
      timestamp: "1 day ago",
      sender: "Narendra Modi"
    },
    isActive: false
  },
  {
    _id: "group3",
    groupName: "Technical Institute Heads",
    groupImage: "https://images.unsplash.com/photo-1558655146-9f40138edfeb?w=150&h=150&fit=crop&auto=format",
    memberCount: 15,
    isGroup: true,
    latestMessage: {
      content: "Research collaboration opportunities",
      timestamp: "3 hours ago",
      sender: "IIT Delhi Professor"
    },
    isActive: true
  },
  {
    _id: "group4",
    groupName: "Medical Education Board",
    groupImage: "https://images.unsplash.com/photo-1517180102446-f3ece451e9d8?w=150&h=150&fit=crop&auto=format",
    memberCount: 6,
    isGroup: true,
    latestMessage: {
      content: "NEET exam preparation guidelines",
      timestamp: "5 hours ago",
      sender: "AIIMS Director"
    },
    isActive: true
  },
  {
    _id: "group5",
    groupName: "Student Affairs Council",
    groupImage: "https://images.unsplash.com/photo-1521737711867-e3b97375f902?w=150&h=150&fit=crop&auto=format",
    memberCount: 20,
    isGroup: true,
    latestMessage: {
      content: "Campus fest coordination meeting",
      timestamp: "1 hour ago",
      sender: "JNU Student Council"
    },
    isActive: true
  },
  {
    _id: "group6",
    groupName: "Academic Excellence Committee",
    groupImage: "https://images.unsplash.com/photo-1524178232363-1fb2b075b655?w=150&h=150&fit=crop&auto=format",
    memberCount: 9,
    isGroup: true,
    latestMessage: {
      content: "Quality assurance framework discussion",
      timestamp: "6 hours ago",
      sender: "VIT Registrar"
    },
    isActive: false
  },
  {
    _id: "group7",
    groupName: "Research & Innovation Hub",
    groupImage: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&auto=format",
    memberCount: 14,
    isGroup: true,
    latestMessage: {
      content: "Patent filing procedures updated",
      timestamp: "4 hours ago",
      sender: "BITS Pilani Admin"
    },
    isActive: true
  },
  {
    _id: "group8",
    groupName: "Digital Learning Initiative",
    groupImage: "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=150&h=150&fit=crop&auto=format",
    memberCount: 11,
    isGroup: true,
    latestMessage: {
      content: "Online platform integration updates",
      timestamp: "2 days ago",
      sender: "Rufina Siddiqui KIIT"
    },
    isActive: true
  }
];

function Group() {
  const {
    chatList,
    fetchChats,
    setSelectedChat,
    createGroupChat,
    fetchChatUsers,
    chatuserList,
    isUsersLoading,
  } = useChatStore();

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [groupName, setGroupName] = useState("");
  const [groupImage, setGroupImage] = useState("");
  const [selectedUsers, setSelectedUsers] = useState([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [imagePreview, setImagePreview] = useState("");
  const [isCreating, setIsCreating] = useState(false);

  useEffect(() => {
    fetchChats();
    fetchChatUsers();
  }, []);

  // Use mock data if store data is not available
  const availableUsers = chatuserList?.length > 0 ? chatuserList : mockUsers;
  const availableGroups = chatList?.filter(chat => chat.isGroup)?.length > 0 
    ? chatList.filter(chat => chat.isGroup) 
    : mockGroups;

  const filteredGroups = availableGroups.filter((group) =>
    group.groupName.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const toggleUserSelection = (userId) => {
    setSelectedUsers((prevSelected) =>
      prevSelected.includes(userId)
        ? prevSelected.filter((id) => id !== userId)
        : [...prevSelected, userId]
    );
  };

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setGroupImage(file);
      const reader = new FileReader();
      reader.onload = (e) => setImagePreview(e.target.result);
      reader.readAsDataURL(file);
    }
  };

  const handleCreateGroup = async () => {
    if (!groupName.trim()) {
      toast.error("Please enter a group name");
      return;
    }
    
    if (selectedUsers.length < 1) {
      toast.error("Please select at least one user");
      return;
    }

    setIsCreating(true);
    
    try {
      await createGroupChat({
        name: groupName,
        users: selectedUsers,
        image: groupImage,
      });

      // Reset form & close modal
      setIsModalOpen(false);
      setGroupName("");
      setGroupImage("");
      setImagePreview("");
      setSelectedUsers([]);
      toast.success("Group created successfully!");
    } catch (error) {
      console.error("Error creating group:", error);
      toast.error("Failed to create group");
    } finally {
      setIsCreating(false);
    }
  };

  const resetModal = () => {
    setIsModalOpen(false);
    setGroupName("");
    setGroupImage("");
    setImagePreview("");
    setSelectedUsers([]);
  };

  const getRoleIcon = (role) => {
    switch (role) {
      case "admin":
        return <Crown className="w-3 h-3 text-yellow-500" />;
      case "moderator":
        return <Shield className="w-3 h-3 text-blue-500" />;
      default:
        return null;
    }
  };

  const getRoleBadgeColor = (role) => {
    switch (role) {
      case "admin":
        return "bg-yellow-100 text-yellow-800 border-yellow-200";
      case "moderator":
        return "bg-blue-100 text-blue-800 border-blue-200";
      default:
        return "bg-gray-100 text-gray-800 border-gray-200";
    }
  };

  return (
    <div className="flex-grow">
      <div className="chat-leftsidebar w-full md:w-[450px] lg:w-[380px] max-w-full bg-white h-screen flex flex-col border-x-[1px] border-gray-200 shadow-sm">
        
        {/* Enhanced Header */}
        <div className="px-6 pt-6 pb-4 bg-gradient-to-r from-white to-gray-50 border-b border-gray-100 flex-shrink-0">
          <div className="flex justify-between items-center mb-4">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-blue-100 rounded-lg">
                <Users className="w-6 h-6 text-blue-600" />
              </div>
              <div>
                <h4 className="text-xl font-semibold text-gray-800">Groups</h4>
                <p className="text-xs text-gray-500">Manage your group chats</p>
              </div>
              <span className="bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded-full font-medium">
                {filteredGroups.length}
              </span>
            </div>
            <button
              onClick={() => setIsModalOpen(true)}
              className="bg-blue-600 hover:bg-blue-700 text-white p-3 rounded-full transition-all duration-200 shadow-lg hover:shadow-xl transform hover:scale-105 active:scale-95"
              title="Create New Group"
            >
              <Plus className="w-5 h-5" />
            </button>
          </div>

          {/* Enhanced Search Bar */}
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search className="h-4 w-4 text-gray-400" />
            </div>
            <input
              onChange={(e) => setSearchQuery(e.target.value)}
              type="text"
              className="block w-full pl-10 pr-3 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white placeholder-gray-400 text-sm transition-all duration-200"
              placeholder="Search groups..."
              value={searchQuery}
            />
          </div>
        </div>

        {/* Enhanced Group List - Fully Scrollable */}
        <div className="flex-1 overflow-y-auto scrollbar-thin scrollbar-thumb-gray-300 scrollbar-track-gray-100">
          {filteredGroups.length > 0 ? (
            <div className="space-y-1 p-2">
              {filteredGroups.map((group) => (
                <div
                  key={group._id}
                  onClick={() => setSelectedChat(group)}
                  className="group flex items-center p-4 hover:bg-gradient-to-r hover:from-blue-50 hover:to-indigo-50 rounded-lg transition-all duration-200 cursor-pointer border border-transparent hover:border-blue-200 hover:shadow-md"
                >
                  <div className="relative flex-shrink-0 mr-4">
                    <img
                      src={group.groupImage || "https://images.unsplash.com/photo-1522071820081-009f0129c71c?w=150&h=150&fit=crop&auto=format"}
                      className="w-14 h-14 rounded-full object-cover ring-2 ring-gray-100 shadow-sm"
                      alt={group.groupName}
                    />
                    {group.isActive && (
                      <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-green-500 border-2 border-white rounded-full animate-pulse"></div>
                    )}
                    <div className="absolute -top-1 -left-1 bg-blue-600 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center font-bold">
                      {group.memberCount > 99 ? '99+' : group.memberCount}
                    </div>
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between mb-1">
                      <h5 className="font-semibold text-gray-900 truncate text-sm flex items-center">
                        {group.groupName}
                        <MessageCircle className="w-3 h-3 ml-2 text-gray-400" />
                      </h5>
                      <span className="text-xs text-gray-500 flex-shrink-0">
                        {group.latestMessage?.timestamp}
                      </span>
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div className="flex-1 min-w-0">
                        <p className="text-sm text-gray-600 truncate">
                          <span className="font-medium text-blue-600">
                            {group.latestMessage?.sender}:
                          </span>{" "}
                          {group.latestMessage?.content || "No messages yet"}
                        </p>
                      </div>
                      <div className="flex items-center space-x-2 ml-2">
                        <span className="text-xs text-gray-400 flex items-center bg-gray-100 px-2 py-1 rounded-full">
                          <Users className="w-3 h-3 mr-1" />
                          {group.memberCount}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center h-full text-gray-500 px-6">
              <div className="bg-gray-100 p-8 rounded-full mb-6">
                <Users className="w-16 h-16 text-gray-300" />
              </div>
              <h3 className="text-lg font-medium text-gray-600 mb-2">No Groups Found</h3>
              <p className="text-center text-gray-400 mb-6">
                {searchQuery ? "No groups match your search criteria" : "Create your first group to get started"}
              </p>
              <button
                onClick={() => setIsModalOpen(true)}
                className="flex items-center space-x-2 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition-colors duration-200"
              >
                <Plus className="w-4 h-4" />
                <span>Create Group</span>
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Enhanced Create Group Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50 p-4">
          <div className="w-full max-w-2xl bg-white shadow-2xl rounded-2xl overflow-hidden max-h-[90vh] flex flex-col">
            
            {/* Modal Header */}
            <div className="bg-gradient-to-r from-blue-600 to-blue-700 px-6 py-4 text-white relative flex-shrink-0">
              <button
                onClick={resetModal}
                className="absolute top-4 right-4 text-white hover:text-gray-200 transition-colors p-1 rounded-full hover:bg-white/20"
              >
                <X className="w-5 h-5" />
              </button>
              <h2 className="text-xl font-semibold flex items-center">
                <UserPlus className="w-6 h-6 mr-3" />
                Create New Group
              </h2>
              <p className="text-blue-100 text-sm mt-1">Add members and customize your group</p>
            </div>

            {/* Modal Content - Scrollable */}
            <div className="flex-1 overflow-y-auto scrollbar-thin scrollbar-thumb-gray-300 scrollbar-track-gray-100">
              <div className="p-6 space-y-6">
                {/* Group Image Section */}
                <div className="text-center">
                  <div className="relative inline-block">
                    <div className="w-24 h-24 bg-gradient-to-br from-blue-100 to-blue-200 rounded-full flex items-center justify-center mx-auto mb-3 overflow-hidden shadow-lg">
                      {imagePreview ? (
                        <img
                          src={imagePreview}
                          alt="Group preview"
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <Image className="w-10 h-10 text-blue-500" />
                      )}
                    </div>
                    <label className="absolute bottom-0 right-0 bg-blue-600 text-white p-2 rounded-full cursor-pointer hover:bg-blue-700 transition-colors shadow-lg">
                      <Image className="w-4 h-4" />
                      <input
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={handleImageChange}
                      />
                    </label>
                  </div>
                  <p className="text-sm text-gray-500">Upload group photo</p>
                </div>

                {/* Group Name Input */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Group Name *
                  </label>
                  <input
                    type="text"
                    placeholder="Enter group name (e.g., University Staff, Project Team)"
                    className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 text-sm"
                    value={groupName}
                    onChange={(e) => setGroupName(e.target.value)}
                  />
                </div>

                {/* User Selection */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-3">
                    Add Members ({selectedUsers.length} selected)
                  </label>
                  <div className="max-h-64 overflow-y-auto border border-gray-200 rounded-lg scrollbar-thin scrollbar-thumb-gray-300 scrollbar-track-gray-100">
                    {isUsersLoading ? (
                      <div className="p-6 text-center text-gray-500">
                        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-2"></div>
                        Loading users...
                      </div>
                    ) : (
                      <div className="divide-y divide-gray-100">
                        {availableUsers.map((user) => (
                          <div
                            key={user._id}
                            onClick={() => toggleUserSelection(user._id)}
                            className={`flex items-center justify-between p-4 cursor-pointer transition-all duration-200 ${
                              selectedUsers.includes(user._id)
                                ? "bg-blue-50 border-l-4 border-blue-500 shadow-sm"
                                : "hover:bg-gray-50"
                            }`}
                          >
                            <div className="flex items-center space-x-4">
                              <div className="relative">
                                <img
                                  src={user.profilePic || "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face&auto=format"}
                                  className="w-12 h-12 rounded-full object-cover shadow-sm"
                                  alt={user.fullName}
                                />
                                {user.isOnline && (
                                  <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 border-2 border-white rounded-full"></div>
                                )}
                              </div>
                              <div className="flex-1">
                                <div className="flex items-center space-x-2 mb-1">
                                  <span className="font-medium text-gray-900 text-sm">
                                    {user.fullName}
                                  </span>
                                  {getRoleIcon(user.role)}
                                </div>
                                <div className="flex items-center space-x-2">
                                  <span className={`text-xs px-2 py-1 rounded-full border ${getRoleBadgeColor(user.role)}`}>
                                    {user.role}
                                  </span>
                                  {user.email && (
                                    <span className="text-xs text-gray-500">{user.email}</span>
                                  )}
                                </div>
                              </div>
                            </div>
                            {selectedUsers.includes(user._id) && (
                              <div className="flex-shrink-0">
                                <Check className="w-5 h-5 text-blue-600" />
                              </div>
                            )}
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>

                {/* Selected Users Pills */}
                {selectedUsers.length > 0 && (
                  <div>
                    <p className="text-sm font-medium text-gray-700 mb-3">Selected Members:</p>
                    <div className="flex flex-wrap gap-2 max-h-24 overflow-y-auto scrollbar-thin scrollbar-thumb-gray-300 scrollbar-track-gray-100">
                      {selectedUsers.map((userId) => {
                        const user = availableUsers.find((u) => u._id === userId);
                        return (
                          <span
                            key={userId}
                            className="inline-flex items-center px-3 py-2 rounded-full text-sm bg-blue-100 text-blue-800 border border-blue-200 shadow-sm"
                          >
                            <img
                              src={user?.profilePic || "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face&auto=format"}
                              className="w-5 h-5 rounded-full mr-2 object-cover"
                              alt={user?.fullName}
                            />
                            {user?.fullName}
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                toggleUserSelection(userId);
                              }}
                              className="ml-2 text-blue-600 hover:text-blue-800 p-1 rounded-full hover:bg-blue-200 transition-colors"
                            >
                              <X className="w-3 h-3" />
                            </button>
                          </span>
                        );
                      })}
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Modal Footer */}
            <div className="px-6 py-4 bg-gray-50 flex justify-end space-x-3 border-t border-gray-200 flex-shrink-0">
              <button
                onClick={resetModal}
                disabled={isCreating}
                className="px-6 py-2 text-gray-700 border border-gray-300 rounded-lg hover:bg-gray-100 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Cancel
              </button>
              <button
                onClick={handleCreateGroup}
                disabled={!groupName.trim() || selectedUsers.length === 0 || isCreating}
                className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors flex items-center space-x-2 shadow-md hover:shadow-lg"
              >
                {isCreating ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                    <span>Creating...</span>
                  </>
                ) : (
                  <>
                    <UserPlus className="w-4 h-4" />
                    <span>Create Group</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      <style jsx>{`
        .scrollbar-thin::-webkit-scrollbar {
          width: 6px;
        }
        .scrollbar-thumb-gray-300::-webkit-scrollbar-thumb {
          background-color: #d1d5db;
          border-radius: 3px;
        }
        .scrollbar-track-gray-100::-webkit-scrollbar-track {
          background-color: #f3f4f6;
        }
        .scrollbar-thumb-gray-300::-webkit-scrollbar-thumb:hover {
          background-color: #9ca3af;
        }
      `}</style>
    </div>
  );
}

export default Group;
