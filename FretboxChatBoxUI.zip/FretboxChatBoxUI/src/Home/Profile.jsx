import React, { useEffect, useState, useRef } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuthStore } from "../store/useAuthStore";

function Profile() {
  const { logout, authUser, setActiveTab } = useAuthStore();
  const navigate = useNavigate();
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [isAccordionOpen, setIsAccordionOpen] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(true);
  const dropdownRef = useRef(null);

  useEffect(() => {
    if (!authUser) {
      navigate("/login");
    }
  }, [authUser, navigate]);

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setIsDropdownOpen(false);
      }
    };

    if (isDropdownOpen) {
      document.addEventListener("mousedown", handleClickOutside);
      document.addEventListener("touchstart", handleClickOutside);
    }

    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
      document.removeEventListener("touchstart", handleClickOutside);
    };
  }, [isDropdownOpen]);

  const handleLogout = async () => {
    await logout();
    setActiveTab("Chats");
  };

  const toggleAccordion = () => {
    setIsAccordionOpen(!isAccordionOpen);
  };

  const closeModal = () => {
    setIsModalOpen(false);
  };

  if (!isModalOpen) return null;

  return (
    <>
      {/* Modal Backdrop */}
      <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
        {/* Modal Content - Half Page Width */}
        <div className="bg-white rounded-lg shadow-2xl w-full max-w-2xl h-[90vh] max-h-[600px] flex flex-col overflow-hidden">
          
          {/* Header Section */}
          <div className="px-6 py-4 border-b border-gray-200 flex-shrink-0">
            <div className="flex justify-between items-center">
              <h4 className="text-xl font-semibold text-gray-800">My Profile</h4>
              <div className="flex items-center space-x-2">
                {/* Dropdown Menu */}
                <div className="relative dropdown" ref={dropdownRef}>
                  <button
                    className="p-2 text-gray-500 hover:text-gray-700 hover:bg-gray-100 rounded-full transition-all duration-200"
                    onClick={() => setIsDropdownOpen(!isDropdownOpen)}
                    aria-label="Profile options"
                  >
                    <i className="text-lg ri-more-2-fill"></i>
                  </button>
                  {isDropdownOpen && (
                    <ul className="absolute z-50 block w-44 py-2 text-left list-none bg-white border border-gray-200 rounded-lg shadow-lg right-0 mt-2 dropdown-menu">
                      <li>
                        <Link
                          className="block w-full px-4 py-3 text-sm text-gray-700 hover:bg-gray-50 transition-colors duration-150"
                          to="#"
                        >
                          <i className="ri-edit-line mr-2"></i>
                          Edit Profile
                        </Link>
                      </li>
                      <li>
                        <Link
                          className="block w-full px-4 py-3 text-sm text-red-600 hover:bg-red-50 transition-colors duration-150"
                          to="#"
                          onClick={handleLogout}
                        >
                          <i className="ri-logout-circle-line mr-2"></i>
                          Logout
                        </Link>
                      </li>
                    </ul>
                  )}
                </div>
                
                {/* Close Button */}
                <button
                  onClick={closeModal}
                  className="p-2 text-gray-500 hover:text-gray-700 hover:bg-gray-100 rounded-full transition-all duration-200"
                  aria-label="Close modal"
                >
                  <i className="text-lg ri-close-line"></i>
                </button>
              </div>
            </div>
          </div>

          {/* Profile Info Section - Horizontal Layout */}
          <div className="px-6 py-6 border-b border-gray-200 flex-shrink-0">
            <div className="flex items-center space-x-6">
              {/* Profile Picture */}
              <div className="flex-shrink-0">
                <div className="relative">
                  <img
                    src={authUser?.profilePic}
                    className="w-20 h-20 rounded-full object-cover border-2 border-gray-200 shadow-sm"
                    alt="Profile"
                  />
                  <div className="absolute bottom-0 right-0 w-5 h-5 bg-green-500 border-2 border-white rounded-full"></div>
                </div>
              </div>
              
              {/* User Information - Horizontal Layout */}
              <div className="flex-1 grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-1">
                  <p className="text-xs font-medium text-gray-500 uppercase tracking-wide">Name</p>
                  <h5 className="text-sm font-semibold text-gray-800">{authUser?.fullName}</h5>
                </div>
                <div className="space-y-1">
                  <p className="text-xs font-medium text-gray-500 uppercase tracking-wide">Email</p>
                  <h5 className="text-sm font-semibold text-gray-800 truncate">{authUser?.email}</h5>
                </div>
                <div className="space-y-1">
                  <p className="text-xs font-medium text-gray-500 uppercase tracking-wide">Role</p>
                  <div className="inline-flex items-center">
                    <i className="text-green-500 mr-1 ri-record-circle-fill text-xs"></i>
                    <span className="text-sm font-semibold text-gray-800">{authUser?.role}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Scrollable Content Section */}
          <div className="flex-1 overflow-hidden">
            <div className="h-full overflow-y-auto px-6 py-6">
              <p className="mb-6 text-gray-600 text-center">
                Welcome to your profile! Here you can see and manage your personal details.
              </p>

              {/* Accordion Section */}
              <div className="space-y-4">
                <div className="border border-gray-200 rounded-lg overflow-hidden">
                  <button
                    type="button"
                    className="flex items-center justify-between w-full px-4 py-4 font-medium text-left bg-gray-50 hover:bg-gray-100 transition-colors duration-200"
                    onClick={toggleAccordion}
                  >
                    <span className="flex items-center text-gray-800">
                      <i className="mr-3 ri-user-2-line text-gray-600"></i>
                      Additional Information
                    </span>
                    <i className={`ri-arrow-down-s-line text-xl text-gray-500 transition-transform duration-200 ${isAccordionOpen ? 'rotate-180' : ''}`}></i>
                  </button>

                  <div className={`bg-white border-t border-gray-100 transition-all duration-300 ease-in-out ${isAccordionOpen ? 'max-h-96 opacity-100' : 'max-h-0 opacity-0 overflow-hidden'}`}>
                    <div className="p-6">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="space-y-4">
                          <div className="p-4 bg-gray-50 rounded-lg">
                            <p className="mb-2 text-xs font-medium text-gray-500 uppercase tracking-wide">Full Name</p>
                            <h5 className="text-sm font-semibold text-gray-800">{authUser?.fullName}</h5>
                          </div>
                          <div className="p-4 bg-gray-50 rounded-lg">
                            <p className="mb-2 text-xs font-medium text-gray-500 uppercase tracking-wide">User Role</p>
                            <h5 className="text-sm font-semibold text-gray-800">{authUser?.role}</h5>
                          </div>
                        </div>
                        <div className="space-y-4">
                          <div className="p-4 bg-gray-50 rounded-lg">
                            <p className="mb-2 text-xs font-medium text-gray-500 uppercase tracking-wide">Email Address</p>
                            <h5 className="text-sm font-semibold text-gray-800 break-all">{authUser?.email}</h5>
                          </div>
                          <div className="p-4 bg-gray-50 rounded-lg">
                            <p className="mb-2 text-xs font-medium text-gray-500 uppercase tracking-wide">Status</p>
                            <div className="flex items-center">
                              <i className="text-green-500 mr-2 ri-record-circle-fill text-sm"></i>
                              <span className="text-sm font-semibold text-green-600">Active</span>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <style jsx>{`
        ::-webkit-scrollbar {
          width: 6px;
        }
        ::-webkit-scrollbar-thumb {
          background-color: #d1d5db;
          border-radius: 3px;
        }
        ::-webkit-scrollbar-track {
          background-color: #f9fafb;
        }
        ::-webkit-scrollbar-thumb:hover {
          background-color: #9ca3af;
        }
      `}</style>
    </>
  );
}

export default Profile;
